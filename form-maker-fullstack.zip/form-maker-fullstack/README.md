# Formly — Full-stack Form Maker

A handwritten HTML/CSS/JavaScript frontend served by a Python FastAPI backend, using PostgreSQL.

## Features
- Register, log in, log out (Argon2 password hashing; HttpOnly signed session cookie)
- Private dashboard and per-owner forms/results
- Manually build short text, paragraph, radio, checkbox, dropdown and date questions
- Publish public forms; receive submissions; validate on server
- Count submissions, show recent 500 answers and choice summaries, export all answers as CSV
- Mobile-friendly blue interface

## Local setup (Windows)
1. Install Python 3.12+ and PostgreSQL, or use a hosted PostgreSQL database.
2. Extract this ZIP, open a terminal inside the project folder.
3. Run `py -m venv .venv` then `.venv\Scripts\activate`.
4. Run `pip install -r requirements.txt`.
5. Copy `.env.example` to `.env`. Put your actual PostgreSQL connection URL in `DATABASE_URL`, a long random secret in `SECRET_KEY`, set `COOKIE_SECURE=false`, and set `ALLOWED_HOSTS=localhost,127.0.0.1`.
6. Run `uvicorn app.main:app --reload`.
7. Open `http://localhost:8000` in your browser.

Generate a secret using: `python -c "import secrets; print(secrets.token_urlsafe(48))"`

## Online deployment (Render + Neon PostgreSQL)
1. Create a PostgreSQL database on https://neon.tech/ and copy its connection string. Keep the password private. The app accepts `postgresql://...` or `postgresql+psycopg://...` URLs.
2. Create a GitHub repository and upload the *extracted project files* (not `.env`). The ZIP is for transferring the project; Render builds from the repository.
3. On https://render.com/ create a new Web Service connected to the repository. Choose **Docker** runtime (the included Dockerfile is detected).
4. Add environment variables: `DATABASE_URL` = Neon connection string, `SECRET_KEY` = long random secret, `COOKIE_SECURE` = `true`, `ALLOWED_HOSTS` = your Render hostname (e.g. `form-maker-web.onrender.com`). If your Render service gets a different hostname, update this value.
5. Deploy. Open your Render HTTPS URL. The app automatically creates tables on first startup. Visit `/api/health` for a simple health check.
6. Register a user, make a form, mark it Published, save, open its public link in an incognito window, submit a response, then check Results and Export CSV.

Free hosting tiers and limits can change; check the providers' current pricing. On some free plans, an idle service may sleep and the first request can be slow.

## Security / production notes
- Passwords use Argon2 hashing; sessions are signed, HttpOnly and SameSite=Lax; CSRF header checking and same-origin checks protect cookie-authenticated changes; forms and results enforce owner checks.
- The database is not exposed to the browser. Keep `SECRET_KEY`, `DATABASE_URL`, and `.env` private. Use HTTPS in production.
- This is a functional starter, **not a production-hardened service for untrusted internet traffic at scale**. Before a public launch, add server-side rate limiting (login/register/submissions), bot protection, email verification, password reset, account deletion, audit logs, migrations (Alembic), database backups, privacy policy, retention policy, monitoring, and a stricter CSP. The public submission endpoint is intentionally open to anonymous users and may be spammed without those protections.
- Changing question structure is blocked after any submissions to avoid corrupting historical results. Title/description/published state can still change.
- Each response is one submission, not a verified unique person. Results show the most recent 500 for display, while CSV includes all.
- For deployment behind a reverse proxy, ensure trusted forwarded headers are configured only for your hosting environment; Render uses a proxy. Review allowed hosts when attaching a custom domain.
