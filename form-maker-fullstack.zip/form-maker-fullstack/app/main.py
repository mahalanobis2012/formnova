import csv
import io
import json
import os
import re
import secrets
import time
from collections import Counter
from contextlib import asynccontextmanager
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from dotenv import load_dotenv
from fastapi import FastAPI, Depends, HTTPException, Request, Response
from fastapi.responses import FileResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired
from pydantic import BaseModel, EmailStr, Field, field_validator
from pwdlib import PasswordHash
from sqlalchemy import Boolean, DateTime, ForeignKey, Integer, JSON, String, Text, create_engine, func, select
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, sessionmaker, Session
from starlette.middleware.trustedhost import TrustedHostMiddleware

load_dotenv()
DATABASE_URL = os.getenv('DATABASE_URL', '')
SECRET_KEY = os.getenv('SECRET_KEY', '')
if len(SECRET_KEY) < 32:
    raise RuntimeError('Set SECRET_KEY to a random value of at least 32 characters')
if not DATABASE_URL:
    raise RuntimeError('DATABASE_URL is required (PostgreSQL)')
if DATABASE_URL.startswith('postgres://'):
    DATABASE_URL = DATABASE_URL.replace('postgres://', 'postgresql+psycopg://', 1)
elif DATABASE_URL.startswith('postgresql://'):
    DATABASE_URL = DATABASE_URL.replace('postgresql://', 'postgresql+psycopg://', 1)
engine = create_engine(DATABASE_URL, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine)
serializer = URLSafeTimedSerializer(SECRET_KEY, salt='form-maker-session-v1')
hasher = PasswordHash.recommended()
SECURE = os.getenv('COOKIE_SECURE', 'true').lower() == 'true'

class Base(DeclarativeBase):
    pass

class User(Base):
    __tablename__ = 'users'
    id: Mapped[int] = mapped_column(primary_key=True)
    email: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Form(Base):
    __tablename__ = 'forms'
    id: Mapped[str] = mapped_column(String(32), primary_key=True)
    owner_id: Mapped[int] = mapped_column(ForeignKey('users.id'), index=True)
    title: Mapped[str] = mapped_column(String(120))
    description: Mapped[str] = mapped_column(String(1000), default='')
    questions: Mapped[list] = mapped_column(JSON, default=list)
    published: Mapped[bool] = mapped_column(Boolean, default=False)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

class Submission(Base):
    __tablename__ = 'submissions'
    id: Mapped[int] = mapped_column(primary_key=True)
    form_id: Mapped[str] = mapped_column(ForeignKey('forms.id', ondelete='CASCADE'), index=True)
    answers: Mapped[dict] = mapped_column(JSON)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))

@asynccontextmanager
async def lifespan(app):
    Base.metadata.create_all(engine)
    yield

app = FastAPI(title='Form Maker API', lifespan=lifespan, docs_url=None, redoc_url=None)
hosts = [h.strip() for h in os.getenv('ALLOWED_HOSTS', 'localhost,127.0.0.1').split(',') if h.strip()]
app.add_middleware(TrustedHostMiddleware, allowed_hosts=hosts)

class Credentials(BaseModel):
    email: EmailStr
    password: str = Field(min_length=10, max_length=128)

class Question(BaseModel):
    id: str = Field(min_length=1, max_length=40, pattern=r'^[a-zA-Z0-9_-]+$')
    label: str = Field(min_length=1, max_length=200)
    type: Literal['short', 'paragraph', 'radio', 'checkbox', 'select', 'date']
    required: bool = False
    options: list[str] = Field(default_factory=list, max_length=30)

    @field_validator('options')
    @classmethod
    def check_options(cls, v):
        if any(not x.strip() or len(x) > 120 for x in v):
            raise ValueError('Options must be nonempty and at most 120 characters')
        return v

class FormPayload(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str = Field(default='', max_length=1000)
    questions: list[Question] = Field(default_factory=list, max_length=60)
    published: bool = False

class AnswersPayload(BaseModel):
    answers: dict[str, str | list[str]]
    website: str = ''  # honeypot


def db_session():
    with SessionLocal() as db:
        yield db

def csrf_guard(request: Request):
    # Reject cross-site browser mutations, including cookie-authenticated actions.
    if request.method in ('POST', 'PUT', 'PATCH', 'DELETE'):
        origin = request.headers.get('origin')
        if origin:
            from urllib.parse import urlsplit
            origin_url = urlsplit(origin)
            expected = request.url
            if origin_url.scheme != expected.scheme or origin_url.netloc != expected.netloc:
                raise HTTPException(403, 'Origin mismatch')
        elif request.headers.get('sec-fetch-site') == 'cross-site':
            raise HTTPException(403, 'Cross-site request rejected')
        if request.cookies.get('session'):
            csrf_cookie = request.cookies.get('csrf')
            csrf_header = request.headers.get('x-csrf-token')
            if not csrf_cookie or not csrf_header or not secrets.compare_digest(csrf_cookie, csrf_header):
                raise HTTPException(403, 'Invalid CSRF token')

def current_user(request: Request, db: Session = Depends(db_session)):
    token = request.cookies.get('session')
    if not token:
        raise HTTPException(401, 'Please sign in')
    try:
        data = serializer.loads(token, max_age=60 * 60 * 24 * 7)
        user_id = int(data['uid'])
    except (BadSignature, SignatureExpired, ValueError, KeyError, TypeError):
        raise HTTPException(401, 'Session expired; sign in again')
    user = db.get(User, user_id)
    if not user:
        raise HTTPException(401, 'Account unavailable')
    return user

def owned_form(form_id: str, user: User, db: Session):
    form = db.get(Form, form_id)
    if not form or form.owner_id != user.id:
        raise HTTPException(404, 'Form not found')
    return form

def form_json(f, count=None):
    d = {'id': f.id, 'title': f.title, 'description': f.description,
         'questions': f.questions, 'published': f.published, 'created_at': f.created_at.isoformat()}
    if count is not None:
        d['response_count'] = count
    return d

def validate_form(payload):
    ids = [q.id for q in payload.questions]
    if len(ids) != len(set(ids)):
        raise HTTPException(422, 'Question IDs must be unique')
    for q in payload.questions:
        if q.type in ('radio', 'checkbox', 'select') and (len(q.options) < 2 or len(set(q.options)) != len(q.options)):
            raise HTTPException(422, 'Choice questions need at least two distinct options')

@app.get('/api/health')
def health():
    return {'status': 'ok'}

@app.post('/api/auth/register', dependencies=[Depends(csrf_guard)])
def register(payload: Credentials, response: Response, db: Session = Depends(db_session)):
    email = str(payload.email).lower()
    if db.scalar(select(User).where(User.email == email)):
        raise HTTPException(409, 'Email already registered')
    user = User(email=email, password_hash=hasher.hash(payload.password))
    db.add(user)
    try:
        db.commit()
        db.refresh(user)
    except Exception:
        db.rollback()
        raise HTTPException(409, 'Could not create account; email may already be registered')
    set_auth(response, user.id)
    return {'id': user.id, 'email': user.email}

@app.post('/api/auth/login', dependencies=[Depends(csrf_guard)])
def login(payload: Credentials, response: Response, db: Session = Depends(db_session)):
    user = db.scalar(select(User).where(User.email == str(payload.email).lower()))
    if not user or not hasher.verify(payload.password, user.password_hash):
        raise HTTPException(401, 'Invalid email or password')
    set_auth(response, user.id)
    return {'id': user.id, 'email': user.email}

def set_auth(response, uid):
    response.set_cookie('session', serializer.dumps({'uid': uid}), max_age=604800, httponly=True, secure=SECURE, samesite='lax', path='/')
    response.set_cookie('csrf', secrets.token_urlsafe(32), max_age=604800, httponly=False, secure=SECURE, samesite='lax', path='/')

@app.get('/api/auth/me')
def me(user: User = Depends(current_user)):
    return {'id': user.id, 'email': user.email}

@app.post('/api/auth/logout', dependencies=[Depends(csrf_guard)])
def logout(response: Response):
    response.delete_cookie('session', path='/')
    response.delete_cookie('csrf', path='/')
    return {'ok': True}

@app.get('/api/forms')
def list_forms(user: User = Depends(current_user), db: Session = Depends(db_session)):
    rows = db.execute(select(Form, func.count(Submission.id)).outerjoin(Submission, Form.id == Submission.form_id)
                      .where(Form.owner_id == user.id).group_by(Form.id).order_by(Form.created_at.desc())).all()
    return [form_json(f, count) for f, count in rows]

@app.post('/api/forms', dependencies=[Depends(csrf_guard)])
def create_form(payload: FormPayload, user: User = Depends(current_user), db: Session = Depends(db_session)):
    validate_form(payload)
    form = Form(id=secrets.token_urlsafe(12), owner_id=user.id, **payload.model_dump())
    db.add(form)
    db.commit()
    db.refresh(form)
    return form_json(form)

@app.get('/api/forms/{form_id}')
def get_form(form_id: str, user: User = Depends(current_user), db: Session = Depends(db_session)):
    return form_json(owned_form(form_id, user, db))

@app.put('/api/forms/{form_id}', dependencies=[Depends(csrf_guard)])
def update_form(form_id: str, payload: FormPayload, user: User = Depends(current_user), db: Session = Depends(db_session)):
    validate_form(payload)
    form = owned_form(form_id, user, db)
    existing_count = db.scalar(select(func.count(Submission.id)).where(Submission.form_id == form_id))
    if existing_count and form.questions != [q.model_dump() for q in payload.questions]:
        raise HTTPException(409, 'Questions cannot be changed after responses exist. Create a new form instead.')
    for k, v in payload.model_dump().items():
        setattr(form, k, v)
    db.commit()
    db.refresh(form)
    return form_json(form)

@app.delete('/api/forms/{form_id}', dependencies=[Depends(csrf_guard)])
def delete_form(form_id: str, user: User = Depends(current_user), db: Session = Depends(db_session)):
    form = owned_form(form_id, user, db)
    db.query(Submission).filter(Submission.form_id == form_id).delete(synchronize_session=False)
    db.delete(form)
    db.commit()
    return {'ok': True}

@app.get('/api/public/{form_id}')
def public_form(form_id: str, db: Session = Depends(db_session)):
    form = db.get(Form, form_id)
    if not form or not form.published:
        raise HTTPException(404, 'Form unavailable')
    return form_json(form)

@app.post('/api/public/{form_id}/submit', dependencies=[Depends(csrf_guard)])
def submit(form_id: str, payload: AnswersPayload, db: Session = Depends(db_session)):
    form = db.get(Form, form_id)
    if not form or not form.published:
        raise HTTPException(404, 'Form unavailable')
    if payload.website:
        return {'ok': True}
    questions = {q['id']: q for q in form.questions}
    if set(payload.answers) - set(questions):
        raise HTTPException(422, 'Unknown question')
    if len(json.dumps(payload.answers)) > 50000:
        raise HTTPException(413, 'Submission too large')
    cleaned = {}
    for qid, q in questions.items():
        value = payload.answers.get(qid, [] if q['type'] == 'checkbox' else '')
        if q['type'] == 'checkbox':
            if not isinstance(value, list) or len(value) > 30 or any(not isinstance(x, str) or x not in q['options'] for x in value):
                raise HTTPException(422, f'Invalid answer for {q["label"]}')
            value = list(dict.fromkeys(value))
            missing = not value
        else:
            if not isinstance(value, str) or len(value) > 5000:
                raise HTTPException(422, f'Invalid answer for {q["label"]}')
            value = value.strip()
            missing = not value
            if q['type'] in ('radio', 'select') and value and value not in q['options']:
                raise HTTPException(422, f'Invalid choice for {q["label"]}')
            if q['type'] == 'date' and value:
                try:
                    datetime.strptime(value, '%Y-%m-%d')
                except ValueError:
                    raise HTTPException(422, 'Invalid date')
        if q['required'] and missing:
            raise HTTPException(422, f'{q["label"]} is required')
        cleaned[qid] = value
    db.add(Submission(form_id=form.id, answers=cleaned))
    db.commit()
    return {'ok': True}

@app.get('/api/forms/{form_id}/results')
def results(form_id: str, user: User = Depends(current_user), db: Session = Depends(db_session)):
    form = owned_form(form_id, user, db)
    subs = db.scalars(select(Submission).where(Submission.form_id == form_id).order_by(Submission.created_at.desc()).limit(500)).all()
    count = db.scalar(select(func.count(Submission.id)).where(Submission.form_id == form_id))
    summaries = []
    for q in form.questions:
        if q['type'] in ('radio', 'select', 'checkbox'):
            tally = Counter()
            for s in subs:
                v = s.answers.get(q['id'])
                if isinstance(v, list):
                    tally.update(v)
                elif v:
                    tally[v] += 1
            summaries.append({'id': q['id'], 'label': q['label'], 'counts': dict(tally)})
    return {'form': form_json(form), 'total': count, 'recent': [{'id': s.id, 'answers': s.answers, 'created_at': s.created_at.isoformat()} for s in subs], 'summaries': summaries, 'sample_size': len(subs)}

@app.get('/api/forms/{form_id}/export')
def export(form_id: str, user: User = Depends(current_user), db: Session = Depends(db_session)):
    form = owned_form(form_id, user, db)
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(['Submission ID', 'Submitted at'] + [q['label'] for q in form.questions])
    for s in db.scalars(select(Submission).where(Submission.form_id == form_id).order_by(Submission.id)).yield_per(100):
        writer.writerow([s.id, s.created_at.isoformat()] + [', '.join(v) if isinstance(v := s.answers.get(q['id'], ''), list) else v for q in form.questions])
    output.seek(0)
    return StreamingResponse(iter([output.getvalue()]), media_type='text/csv; charset=utf-8', headers={'Content-Disposition': f'attachment; filename="form-{form.id}.csv"'})

STATIC = Path(__file__).resolve().parent.parent / 'static'
app.mount('/assets', StaticFiles(directory=STATIC), name='assets')
@app.get('/')
def homepage():
    return FileResponse(STATIC / 'index.html')
@app.get('/{path:path}')
def spa(path: str):
    if path.startswith('api/'):
        raise HTTPException(404)
    return FileResponse(STATIC / 'index.html')
